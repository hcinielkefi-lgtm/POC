# Pixel-V2 – Testing & Observability Guide

Generated: 2025-09-27T16:42:30.160075Z

## 1. Prerequisites
- Docker/Podman
- Camel K (`kamel`), Kaoto (optional)
- Postman

## 2. Start Dependencies
```bash
docker-compose up -d
```
Services:
- Kafka: 9092
- Postgres: 5432 (tables auto-created)
- Prometheus: 9090
- Grafana: 3000 (admin/admin)
- Jaeger: 16686
- Hawtio: 7777

## 3. Run a Flow (example pacs.008)
```bash
kamel run POC/Integration/flows/pacs008-flow.yaml   --resource file:POC/Technical-Framework/xsd/cdm/payment-cdm.xsd   --resource file:POC/Technical-Framework/mappings/pacs008-to-cdm.xsl   --dev
```

## 4. Send Test Messages
- Import `POC/Pixel-V2.postman_collection.json` in Postman
- Use files under `POC/samples/`

## 5. Verify
### Kafka
`processing_cdm` topic should receive CDM XML.

### Database
```sql
SELECT * FROM payment_audit_log ORDER BY timestamp DESC;
SELECT transaction_id, LEFT(payload,200) AS preview, error_details FROM payment_dead_letter ORDER BY timestamp DESC;
```

## 6. Metrics & Dashboard
- Prometheus: http://localhost:9090
- Grafana: http://localhost:3000 (Dashboard: Pixel-V2 Monitoring)
- Metrics emitted:
  - `payments_success_total`
  - `payments_error_total`
  - `payments_dlq_total`
  - `payments_processing_time_seconds` (ms)
- Labels on all metrics: `trace_id`, `transaction_id`
- Latency by TransactionId table is included.

## 7. Tracing (Jaeger)
- Jaeger UI: 

- Traces named `Payment-<transactionId>`
- `trace_id` also stored in audit and DLQ tables.

## 8. Hawtio (Camel Console)
- http://localhost:7777/hawtio
- Jolokia auto-discovery enabled on port 8778.

## 9. DLQ & Retries
- Retries: 3 with 2s delay in `onException`
- On failure: audit + dlq-to-db + Kafka DLQ + metrics increment.


## 13. Dynamic Multi‑Recipient Routing (DB‑Driven, Kamelet‑only)

### Table
`payment_routing_rules(format, recipients, is_active)` — recipients is a **comma‑separated list of Kamelet URIs** (e.g. `kamelet:audit-to-db,kamelet:kafka-producer?topic=corebanking`).

### Seed Rules
Seed data is loaded automatically at startup (see `create_audit_table.sql`).

### Dynamic Entry Point
POST any ISO20022/MT message to `http://localhost:8080/payments`.  
The flow will detect the `format`, look up recipients from DB, and **fan‑out** to all listed Kamelets.

### Manage Rules (Admin API)
- **Add**: 
  ```bash
  curl -X POST http://localhost:8080/admin/routing     -H "Content-Type: application/json"     -d '{ "format": "pacs008", "recipients": "kamelet:audit-to-db,kamelet:kafka-producer?topic=aml", "is_active": true }'
  ```
- **Update**:
  ```bash
  curl -X PUT http://localhost:8080/admin/routing     -H "Content-Type: application/json"     -d '{ "format": "pacs008", "recipients": "kamelet:audit-to-db,kamelet:kafka-producer?topic=corebanking,kamelet:kafka-producer?topic=aml", "is_active": true }'
  ```
- **List**:
  ```bash
  curl "http://localhost:8080/admin/routing"
  # or single format
  curl "http://localhost:8080/admin/routing?format=pacs008"
  ```

### Observability
- Audit `ROUTED` step captures recipients.
- Metrics carry labels: `format`, `trace_id`, `transaction_id`.
- Jaeger shows a **fan‑out** trace (one span per Kamelet recipient).


## 14. Asynchronous Audit Logging (Kafka) & Scaling

All flows now publish audit events to **Kafka topic `payments.audit`** instead of writing to DB inline.

A dedicated consumer persists audits to DB:
- Flow: `POC/Integration/flows/audit-consumer-flow.yaml`
- Kafka endpoint: `kafka:payments.audit?groupId=audit-consumer`
- Micrometer counters: `audit_success_total`, `audit_error_total`

### Run the consumer
```bash
kamel run POC/Integration/flows/audit-consumer-flow.yaml
```

### Horizontal Scaling
There are two ways to scale audit processing:
1. **Multi-threaded consumer (single pod):**
   - The flow uses `consumersCount={{AUDIT_CONSUMERS_COUNT:3}}` (default 3 threads).
   - Override via env/property: `AUDIT_CONSUMERS_COUNT=6`.

2. **Multi-instance consumer (recommended):**
   - Run **multiple instances** of `audit-consumer-flow.yaml` with the **same `groupId=audit-consumer`**.
   - Kafka will distribute partitions across instances for true horizontal scale.

> Headers (`transactionId`, `step`, `status`, `details`, `traceId`) are preserved by Kafka and used by the `audit-to-db` Kamelet.


## 15. Audit Retry, DLQ & Replay

### Retry Policy
- Each audit event is retried **up to 5 times** with exponential backoff (2s, 4s, 8s, 16s, 32s).
- If still failing, the event is sent to a dedicated Kafka DLQ: `payments.audit.dlq`.

### DLQ Handling
- Flow: `POC/Integration/flows/audit-consumer-flow.yaml` routes to DLQ after permanent failure.
- Metrics:
  - `audit_success_total`
  - `audit_error_total`
  - `audit_dlq_total`

### Replay Flow
- Flow: `POC/Integration/flows/audit-dlq-replay-flow.yaml`
- Consumes from `payments.audit.dlq` and republishes to `payments.audit`.

### Run Replay
```bash
kamel run POC/Integration/flows/audit-dlq-replay-flow.yaml
```
This allows re-processing of failed audit events once the DB or downstream system is healthy again.


# 🧪 QA & Validation Plan

This section describes how to validate the Pixel-V2 enhanced project end‑to‑end.

## 1. Environment Setup
1. Start dependencies:
   ```bash
   docker-compose up -d
   ```
2. Deploy flows:
   ```bash
   kamel run POC/Integration/flows/dynamic-payments-flow.yaml
   kamel run POC/Integration/flows/audit-consumer-flow.yaml
   # optional
   kamel run POC/Integration/flows/audit-dlq-replay-flow.yaml
   ```

## 2. Basic Functional Test
- Send a valid pacs.008 sample to `/payments` → expect CDM in Kafka `processing_cdm`, audit in DB, trace in Jaeger, metrics in Grafana.
- Send an invalid pacs.008 sample → expect DLQ entry in DB + `payments_dlq_total` increment.

## 3. Dynamic Routing Test
- Query rules: `curl http://localhost:8080/admin/routing`.
- Add/update a rule using `POST/PUT /admin/routing`.
- Send matching ISO20022 message → confirm fan‑out to configured Kamelets.

## 4. Asynchronous Audit Test
- Check that audit events go to Kafka topic `payments.audit`.
- Stop Postgres, send a payment → observe retries + eventual DLQ (`payments.audit.dlq`).
- Restart Postgres, run replay flow → confirm DLQ events reprocessed.

## 5. Observability Validation
- Grafana: metrics counters + latency per transactionId.
- Jaeger: traces named `Payment-<transactionId>-<format>` with fan‑out spans.
- Hawtio: routes, processors, endpoints visible.

## 6. Negative Tests
- Send unsupported message type → should be routed to DLQ.
- Disable routing rule (`is_active=false`) → sending message of that type should result in no routing.

## 7. Performance / Scale Smoke Test
- Send 100+ pacs.008 messages (loop/JMeter).
- Observe Kafka audit topic grows, consumer keeps up.
- Monitor Grafana throughput & latency.

---

✅ Expected result:  
- Valid messages processed, transformed, audited asynchronously.  
- Invalid messages sent to DLQ.  
- Audits retried, DLQ’ed, replayed successfully.  
- Full visibility in Grafana, Jaeger, Hawtio.  
