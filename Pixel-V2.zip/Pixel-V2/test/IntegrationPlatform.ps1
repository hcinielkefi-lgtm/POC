# Méthode 1 : Fichier YAML séparé
@"
apiVersion: camel.apache.org/v1
kind: IntegrationPlatform
metadata:
  name: camel-k
  namespace: camel-k
spec:
  build:
    publishStrategy: Buildah
    registry: {}
    timeout: "10m"
  configuration:
  - type: property
    value: camel.main.streamCaching=true
"@ | kubectl apply -n camel-k -f -