Write-Host "🔄 Surveillance Camel K - Ctrl+C pour arrêter" -ForegroundColor Green
Write-Host "=============================================="

$iteration = 0
while ($true) {
    $iteration++
    Clear-Host
    Write-Host "=== Itération $iteration - $(Get-Date -Format 'HH:mm:ss') ===" -ForegroundColor Cyan
    
    # 1. Intégrations
    Write-Host "`n📦 INTÉGRATIONS:" -ForegroundColor Yellow
    kubectl get integration -n camel-k 2>&1 | Out-Host
    
    # 2. Kits
    Write-Host "`n🔧 INTEGRATION KITS:" -ForegroundColor Yellow
    kubectl get integrationkit -n camel-k 2>&1 | Out-Host
    
    # 3. Pods importants
    Write-Host "`n🐳 PODS CAMEL K:" -ForegroundColor Yellow
    kubectl get pods -n camel-k --field-selector=status.phase!=Succeeded 2>&1 | Out-Host
    
    # 4. Détails de l'intégration fresh-test
    Write-Host "`n🔍 DÉTAILS fresh-test:" -ForegroundColor Yellow
    $phase = kubectl get integration fresh-test -n camel-k -o jsonpath='{.status.phase}' 2>$null
    $kit = kubectl get integration fresh-test -n camel-k -o jsonpath='{.status.integrationKit}' 2>$null
    Write-Host "   Phase: $phase" -ForegroundColor $(if ($phase -eq "Running") { "Green" } else { "White" })
    Write-Host "   Kit: $kit" -ForegroundColor White
    
    # 5. Événements récents
    Write-Host "`n📋 ÉVÉNEMENTS RÉCENTS:" -ForegroundColor Yellow
    kubectl get events -n camel-k --sort-by='.lastTimestamp' --tail=3 2>&1 | Out-Host
    
    Write-Host "`n⏳ Prochaine mise à jour dans 10 secondes..." -ForegroundColor Gray
    Start-Sleep 10
}