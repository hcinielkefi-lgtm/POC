#!/bin/bash
set -e

COUNT=${1:-100}
SAMPLE=../POC/samples/pacs008-sample.xml

echo "Sending $COUNT pacs008 messages to /payments..."

for i in $(seq 1 $COUNT); do
  curl -s -o /dev/null -w "%{http_code}\n"     -X POST http://localhost:8080/payments     -H "Content-Type: application/xml"     --data-binary @$SAMPLE
done

echo "Load test completed."
