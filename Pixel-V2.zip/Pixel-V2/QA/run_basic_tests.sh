#!/bin/bash
set -e

echo "Running basic Pixel-V2 QA tests..."

# Valid pacs008
curl -s -o /dev/null -w "%{http_code}\n"   -X POST http://localhost:8080/payments   -H "Content-Type: application/xml"   --data-binary @../POC/samples/pacs008-sample.xml

# Invalid pacs008
curl -s -o /dev/null -w "%{http_code}\n"   -X POST http://localhost:8080/payments   -H "Content-Type: application/xml"   --data-binary @../POC/samples/pacs008-invalid.xml

echo "Check audit DB for ROUTED entries..."
python3 check_db.py audit

echo "Check DLQ for invalid messages..."
python3 check_db.py dlq
