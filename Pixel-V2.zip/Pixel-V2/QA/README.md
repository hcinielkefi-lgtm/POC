# QA Scripts for Pixel-V2

## Prerequisites
- Kafka & Postgres running (`docker-compose up -d`)
- Flows deployed (`kamel run ...`)
- Python3 with `psycopg2` and `kafka-python` installed

## Scripts
- `run_basic_tests.sh` → quick smoke test (valid/invalid pacs.008, DB checks)
- `send_message.py` → send any XML message to /payments
- `check_db.py` → query audit or DLQ tables
- `check_kafka.py` → tail Kafka audit and DLQ topics

## Usage
```bash
cd QA
./run_basic_tests.sh
python3 send_message.py pacs008 ../POC/samples/pacs008-sample.xml
python3 check_db.py audit
python3 check_kafka.py
```


## Load Testing
- `load_test.sh` → send N pacs.008 messages (default 100).
```bash
./load_test.sh 200   # send 200 messages
```
Monitor:
- Kafka topic `processing_cdm`
- Grafana throughput panels
- Audit consumer lag & metrics
```


## Load Testing
- `load_test.sh [N]` → send N (default 100) sequential pacs.008 messages.
- `load_test.py [N] [workers]` → send N pacs.008 messages in parallel (default 100 msgs, 10 workers).

Examples:
```bash
./load_test.sh 200
python3 load_test.py 500 20
```
Monitor Grafana dashboards and Kafka lag during these tests.


## Grafana Dashboard for Load Testing
A prebuilt Grafana dashboard JSON is available at:
`POC/Monitoring/grafana/pixel-v2-load-performance-dashboard.json`

Import it into Grafana to monitor:
- Payments success/error/DLQ counts
- Audit success/error/DLQ counts
- Processing latency (ms)
- Kafka audit topic lag per partition
- DLQ topic backlog

Use this dashboard during `load_test.sh` runs.


## Audit Log GUI
A simple Flask-based web GUI to view audit logs.

### Usage
```bash
cd QA/gui
pip install flask psycopg2-binary
python3 audit_gui.py
```
Then open [http://localhost:5000](http://localhost:5000) in your browser.

### Features
- Shows latest 100 audit log entries
- Filter by `transactionId` and/or `status`
- Displays transactionId, step, status, details, timestamp
