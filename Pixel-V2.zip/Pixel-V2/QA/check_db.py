import psycopg2, sys

mode = sys.argv[1] if len(sys.argv) > 1 else "audit"

conn = psycopg2.connect("dbname=pixel user=postgres password=postgres host=localhost")
cur = conn.cursor()

if mode == "audit":
    cur.execute("SELECT transaction_id, step, status, details FROM payment_audit_log ORDER BY timestamp DESC LIMIT 10")
elif mode == "dlq":
    cur.execute("SELECT transaction_id, error_details FROM payment_dead_letter ORDER BY timestamp DESC LIMIT 10")
else:
    print("Unknown mode, use 'audit' or 'dlq'")
    sys.exit(1)

for row in cur.fetchall():
    print(row)
