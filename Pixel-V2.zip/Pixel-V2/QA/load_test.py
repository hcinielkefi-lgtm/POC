import sys, requests
from concurrent.futures import ThreadPoolExecutor

count = int(sys.argv[1]) if len(sys.argv) > 1 else 100
workers = int(sys.argv[2]) if len(sys.argv) > 2 else 10
sample_file = "../POC/samples/pacs008-sample.xml"

with open(sample_file, "rb") as f:
    data = f.read()

def send(i):
    r = requests.post("http://localhost:8080/payments",
                      headers={"Content-Type": "application/xml"},
                      data=data)
    print(f"{i}: {r.status_code}")

print(f"Sending {count} pacs008 messages with {workers} workers...")
with ThreadPoolExecutor(max_workers=workers) as executor:
    for i in range(count):
        executor.submit(send, i+1)
