import sys, requests

if len(sys.argv) < 3:
    print("Usage: send_message.py <format> <file>")
    sys.exit(1)

fmt, file = sys.argv[1], sys.argv[2]
url = "http://localhost:8080/payments"

with open(file, "rb") as f:
    r = requests.post(url, headers={"Content-Type": "application/xml"}, data=f.read())

print(f"Sent {fmt} ({file}), response: {r.status_code}")
