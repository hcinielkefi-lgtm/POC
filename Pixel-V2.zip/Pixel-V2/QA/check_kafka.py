from kafka import KafkaConsumer

topics = ["payments.audit", "payments.audit.dlq"]
consumer = KafkaConsumer(*topics, bootstrap_servers="localhost:9092",
                         group_id="qa-checker", auto_offset_reset="earliest")

print("Listening for audit/DLQ events (Ctrl+C to stop)...")
for msg in consumer:
    print(f"[{msg.topic}] {msg.value.decode()}")
