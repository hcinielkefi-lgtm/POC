from flask import Flask, render_template, request
import psycopg2

app = Flask(__name__)

def get_db_connection():
    return psycopg2.connect("dbname=pixel user=postgres password=postgres host=localhost")

@app.route("/")
def index():
    txid = request.args.get("transactionId")
    status = request.args.get("status")
    query = "SELECT transaction_id, step, status, details, timestamp FROM payment_audit_log WHERE 1=1"
    params = []
    if txid:
        query += " AND transaction_id=%s"
        params.append(txid)
    if status:
        query += " AND status=%s"
        params.append(status)
    query += " ORDER BY timestamp DESC LIMIT 100"

    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute(query, params)
    rows = cur.fetchall()
    cur.close()
    conn.close()

    return render_template("audit.html", logs=rows)

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
