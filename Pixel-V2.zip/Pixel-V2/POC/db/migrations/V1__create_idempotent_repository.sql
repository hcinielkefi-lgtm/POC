-- Flyway-compatible migration
CREATE TABLE IF NOT EXISTS idempotent_repository (
  id VARCHAR(255) PRIMARY KEY,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
