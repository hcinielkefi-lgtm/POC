#!/bin/bash
# scripts/deploy-integration.sh

INTEGRATION_FILE=$1

if [ -z "$INTEGRATION_FILE" ]; then
  echo "Usage: $0 <integration-file>"
  exit 1
fi

echo "Deploying integration: $INTEGRATION_FILE"
kamel run "$INTEGRATION_FILE"


## ./scripts/deploy-integration.sh integrations/pain001-flow.yaml
# NOTE: Ensure Kafka topics (payments.inbound, payments.processing, payments.outbound, payments.dlq) exist and secrets are provisioned (Vault/SealedSecrets).
