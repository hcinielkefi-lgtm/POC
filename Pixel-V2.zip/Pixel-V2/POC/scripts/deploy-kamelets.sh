#!/bin/bash
# scripts/deploy-kamelets.sh

for kamelet_dir in ../kamelets/*; do
  echo "Deploying Kamelet: $kamelet_dir"
  kamel bind "$kamelet_dir/kamelet.yaml"
done
