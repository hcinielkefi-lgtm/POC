#!/bin/bash
# 📁 scripts/deployment/promote-release.sh

FROM_ENV=$1
TO_ENV=$2
VERSION=$3

echo "🔄 Promoting from $FROM_ENV to $TO_ENV (v$VERSION)"

# Backup de l'environnement cible
kubectl get all -n payment-$TO_ENV > backup-$TO_ENV-$(date +%s).yaml

# Mise à jour de la version
sed -i "s/version: .*/version: $VERSION/" config/overlays/$TO_ENV/kustomization.yaml

# Déploiement
./scripts/deployment/deploy-to-environment.sh $TO_ENV $VERSION

# Tests de regression
./scripts/test/regression-tests.sh $TO_ENV

echo "✅ Promotion to $TO_ENV completed"