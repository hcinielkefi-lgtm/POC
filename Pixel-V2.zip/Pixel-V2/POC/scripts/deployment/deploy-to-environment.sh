#!/bin/bash
# 📁 scripts/deployment/deploy-to-environment.sh

ENVIRONMENT=$1
VERSION=$2

echo "🚀 Deploying version $VERSION to $ENVIRONMENT"

# Validation
kustomize build config/overlays/$ENVIRONMENT | kubeval --strict

# Déploiement
kustomize build config/overlays/$ENVIRONMENT | kubectl apply -f -

# Attente du readiness
kubectl wait --for=condition=ready pod -l app=payment-processor \
  -n payment-$ENVIRONMENT --timeout=600s

# Tests smoke
./scripts/test/smoke-tests.sh $ENVIRONMENT

echo "✅ Deployment to $ENVIRONMENT completed"