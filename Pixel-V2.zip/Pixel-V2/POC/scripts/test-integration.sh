#!/bin/bash
# scripts/deploy-integration.sh

INTEGRATION_FILE=$1

if [ -z "$INTEGRATION_FILE" ]; then
  echo "Usage: $0 <integration-file>"
  exit 1
fi

echo "Deploying integration: $INTEGRATION_FILE"
kamel run "$INTEGRATION_FILE"

## example 
## ./scripts/deploy-integration.sh integrations/pain001-flow.yaml