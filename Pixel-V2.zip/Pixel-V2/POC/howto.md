 minikube start --force --driver=docker
 
 docker logs pixel-v2-hawtio-1
 
 
 kubectl config use-context docker-desktop
 
 jbang camel@apache/camel run *.yaml --dev
 
 kubectl get kamelets -n camel-k
 
 # Vérifier que l'opérateur Camel K tourne
kubectl get pods -n camel-k
# Vérifier les CRDs
kubectl get crd | grep camel
# Vérifier les Kamelets disponibles
kubectl get kamelets -n camel-k


kamel log pain001-http-validator


# Vérifier le contenu actuel de votre Kamelet
kubectl get kamelet pain001-validator -o yaml > pain001-validator-backup.yaml
# Supprimer de default
kubectl delete kamelet pain001-validator
# Appliquer dans camel-k
kubectl apply -n camel-k -f pain001-validator.kamelet.yaml
# Vérifier
kubectl get kamelets -n camel-k


# Surveiller le statut
kubectl get integrationplatform -n camel-k -w

kubectl delete integrationplatform camel-k -n camel-k


# Supprimer l'intégration en erreur
kamel delete http-test-route -n camel-k

# Recréer avec plus de verbosité
kamel run --dev -n camel-k -d camel:platform-http -d camel:log -t logging.level=DEBUG http-test-route.yaml --resource configmap:pain001-schemas@/etc/camel/resources/pain.001.xsd

# Tester votre endpoint
kubectl port-forward -n camel-k service/http-test-route 8080:8080

curl http://localhost:8080/test
curl http://localhost:8080/health


# Créer la ConfigMap avec le fichier XSD
kubectl create configmap pain001-schemas -n camel-k --from-file=schemas/ --dry-run=client -o yaml | kubectl apply -f -


kubectl apply -f ConfigMap.yaml -n camel-k
# Vérifier la ConfigMap
kubectl get configmap pain001-schemas -n camel-k -o yaml


# Supprimer tous les builders en erreur
kubectl delete pod -n camel-k -l camel.apache.org/component=kit

# Supprimer les integrationkits corrompus
kubectl delete integrationkit --all -n camel-k

# Vérifier que tout est nettoyé
kubectl get pods -n camel-k
kubectl get integrationkit -n camel-k

kubectl describe integration test-integration -n camel-k

# Nettoyer tout
kubectl delete integrationkit --all -n camel-k
kubectl delete pod -n camel-k -l camel.apache.org/component=kit

kubectl get integration light-test -n camel-k -o yaml


# Nettoyer TOUT complètement
kubectl delete integration --all -n camel-k 2>$null
kubectl delete integrationkit --all -n camel-k 2>$null
kubectl delete pod -n camel-k -l camel.apache.org/component=kit 2>$null

kubectl get integrationplatform camel-k -n camel-k
 kubectl get integrationplatform camel-k -n camel-k -o yaml

 kubectl apply -n camel-k -f light-test.yaml     
 kubectl describe integration light-test -n camel-k
 
  kubectl get integrationplatform camel-k -n camel-k 
  
  
  while ($true) { Clear-Host; kubectl get integration,integrationkit,pods -n camel-k; Write-Host "=== $(Get-Date) ==="; Start-Sleep 10 }
  
  
  kubectl delete events --all -n camel-k
  kubectl get events -n camel-k 
  
  
  kubectl get pods -n camel-k
  kubectl logs <nom-du-pod-de-build> -n camel-k


# 1. Installer Minikube
choco install minikube -y

# 2. Démarrer Minikube
minikube start --memory=4096 --cpus=2 --driver=docker
minikube dashboard
 --> http://127.0.0.1:62752/api/v1/namespaces/kubernetes-dashboard/services/http:kubernetes-dashboard:/proxy/#/workloads?namespace=camel-k
minikube status

# Enable Minikube registry if not already enabled
minikube addons enable registry

# Update the IntegrationPlatform
kubectl patch integrationplatform camel-k -n camel-k --type merge -p '
spec:
  build:
    registry:
      address: $(minikube ip):5000
      insecure: true
    publishStrategy: Buildah
'

# 3. Installer Camel K
helm install camel-k camel-k/camel-k --namespace camel-k --create-namespace --wait



kubectl get builds -n camel-k
kubectl describe build kit-d3dfvtakv4lc738o1a60 -n camel-k