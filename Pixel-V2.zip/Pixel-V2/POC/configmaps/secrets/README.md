Secrets handling recommendations
---------------------------------

- Do NOT store plaintext secrets in the repository.
- Use HashiCorp Vault, Kubernetes SealedSecrets, or External Secrets Controller to provision secrets per environment.
- Example secrets to store externally: DB credentials, Kafka TLS keys, API keys, payment gateway credentials.
- Ensure RBAC limits who can read secrets, and rotate secrets regularly.
