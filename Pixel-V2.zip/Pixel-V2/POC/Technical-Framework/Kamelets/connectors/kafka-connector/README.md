Kafka Kamelet (producer)
----------------------

Simple Kafka producer Kamelet to send messages to Kafka topics.

Usage example in a Camel flow:
- to: "kamelet:kafka-producer?brokers={{KAFKA_BOOTSTRAP_SERVERS}}&topic={{KAFKA_TOPIC}}&key=${header.someKey}"

Note: In Kubernetes production, configure broker TLS/auth via environment variables and secrets.
