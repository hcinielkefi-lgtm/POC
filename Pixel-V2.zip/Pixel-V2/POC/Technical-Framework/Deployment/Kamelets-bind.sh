kamel bind kamelets/connectors/http-connector/kamelet.yaml
kamel bind kamelets/connectors/mq-connector/kamelet.yaml
kamel bind kamelets/connectors/tcp-connector/kamelet.yaml
kamel bind kamelets/pain001-validator/kamelet.yaml
kamel bind kamelets/fraud-detector/kamelet.yaml
kamel bind kamelets/data-transformer/kamelet.yaml
kamel bind kamelets/structured-logger/kamelet.yaml
kamel bind kamelets/dynamic-router/kamelet.yaml
