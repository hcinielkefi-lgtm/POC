kubectl get kamelets
