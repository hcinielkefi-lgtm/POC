Payment CDM & Mapping Guide
==========================

Generated on: 2025-09-26T23:32:31.451418Z

What is included:
- ISO20022-based Canonical CDM XSD: Technical-Framework/xsd/cdm/payment-cdm.xsd
- Kaoto mapping files (YAML) in Technical-Framework/mappings/
  - pacs008-to-cdm.yaml
  - pain001-to-cdm.yaml
  - pain002-to-cdm.yaml
  - pacs002-to-cdm.yaml
  - swift-mt103-to-cdm.yaml
- Transformer Kamelets in Technical-Framework/Kamelets/transformers/
  - xml-transform (generic)
  - transform-*-to-cdm kamelets that call xml-transform wrapper
- Integration flows in Integration/flows/ for each message type
  - Each flow validates input, runs map -> CDM, validates CDM, publishes to Kafka processing topic
- Placeholder ISO20022 XSDs under Technical-Framework/xsd/iso20022/ (replace with official XSDs)
- Placeholder Swift XSD for MT103 (replace with parsing/transform logic for text based MT messages)

Next steps:
- Replace placeholder ISO20022 XSDs with official schemas.
- Implement mapping execution inside xml-transform Kamelet (e.g., XSLT, mapping engine, or script).
- Wire actual Kafka bootstrap servers and topic names via ConfigMaps/Secrets (endpoints.configmap.yaml).
- Ensure jdbcIdempotentRepo bean exists and is configured in Camel context (DB migration provided earlier).
- Import Kaoto YAMLs into Kaoto UI to visually refine mappings.

