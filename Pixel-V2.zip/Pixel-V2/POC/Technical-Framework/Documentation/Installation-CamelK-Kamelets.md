🚀 Guide d'Installation Rapide - Camel K & Kamelets
📋 Prérequis
Windows 10/11 avec PowerShell

Docker Desktop avec Kubernetes activé

Accès administrateur

🔧 INSTALLATION RAPIDE
1. Activer Kubernetes dans Docker Desktop
text
Settings > Kubernetes > [✓] Enable Kubernetes > Apply & Restart
2. Installer les outils en une commande
powershell
# Lancer PowerShell en administrateur et exécuter:
choco install kubernetes-helm -y
3. Installer Camel K CLI
powershell
curl -LO https://github.com/apache/camel-k/releases/download/v2.8.0/camel-k-client-2.8.0-windows-amd64.tar.gz
tar -xzf camel-k-client-2.8.0-windows-amd64.tar.gz
mv kamel.exe "C:\Windows\System32\"
4. Installer Camel K avec Helm
powershell
helm repo add camel-k https://apache.github.io/camel-k/charts
helm repo update
helm install camel-k camel-k/camel-k --namespace camel-k --create-namespace --wait
5. Configurer la plateforme
powershell
kubectl apply -n camel-k -f - @"
apiVersion: camel.apache.org/v1
kind: IntegrationPlatform
metadata:
  name: camel-k
spec:
  build:
    registry:
      insecure: true
"@
✅ VÉRIFICATION
Vérification étape par étape
powershell
# 1. Vérifier Kubernetes
kubectl cluster-info
kubectl get nodes

# 2. Vérifier Helm
helm version

# 3. Vérifier Camel K CLI
kamel version

# 4. Vérifier l'opérateur Camel K
kubectl get pods -n camel-k

# 5. Vérifier les CRDs
kubectl get crd | findstr "camel"

# 6. Vérifier les Kamelets
kubectl get kamelets -n camel-k
Statuts attendus
text
✅ Kubernetes:       Cluster running
✅ Helm:            version 3.x
✅ Kamel:           version 2.8.0
✅ Camel K Operator: Running (1/1)
✅ CRDs:           3 found (integrations, integrationplatforms, kamelets)
✅ Kamelets:       Available
🧪 TEST RAPIDE
1. Tester avec un Kamelet officiel
powershell
kubectl apply -f https://raw.githubusercontent.com/apache/camel-kamelets/main/kamelets/timer-source.kamelet.yaml
kubectl get kamelets
2. Créer un test d'intégration
powershell
kamel run --dev -d camel:timer -d camel:log @"
from('timer:test?period=5000')
  .setBody().constant('Test Réussi!')
  .to('log:info')
"@
3. Vérifier le fonctionnement
powershell
kamel get
kamel log <integration-name>
🔧 DÉPANNAGE RAPIDE
Erreur: "no matches for kind 'Kamelet'"
powershell
# Réinstaller les CRDs
kubectl apply -f https://github.com/apache/camel-k/releases/download/v2.8.0/camel-k-crds-2.8.0.yaml
Erreur: "Invalid value" dans les labels
yaml
# ❌ INCORRECT (virgules interdites)
labels:
  camel.apache.org/kamelet.context: "banking,validation,xml"

# ✅ CORRECT
annotations:
  camel.apache.org/kamelet.context: "banking,validation,xml"
labels:
  camel.apache.org/kamelet.type: "action"
Camel K operator ne démarre pas
powershell
# Redémarrer l'opérateur
kubectl delete pod -n camel-k -l app=camel-k

# Vérifier les logs
kubectl logs -n camel-k -l app=camel-k
Réinitialisation complète
powershell
kamel uninstall --all
helm uninstall camel-k -n camel-k
kubectl delete namespace camel-k
kubectl delete crd kamelets.camel.apache.org integrations.camel.apache.org integrationplatforms.camel.apache.org

# Puis réinstaller
helm install camel-k camel-k/camel-k --namespace camel-k --create-namespace --wait
Commandes de diagnostic utiles
powershell
# Voir tous les pods
kubectl get pods -A

# Voir les événements
kubectl get events --sort-by='.lastTimestamp'

# Vérifier l'espace disque
kubectl top nodes

# Logs détaillés
kubectl logs -n camel-k deployment/camel-k-operator
📞 URGENCES
Si rien ne fonctionne:
Redémarrer Docker Desktop

Réactiver Kubernetes dans les paramètres

Relancer l'installation complète

URLs importantes:
Téléchargement Camel K: https://github.com/apache/camel-k/releases

Documentation: https://camel.apache.org/camel-k/

Kamelets: https://github.com/apache/camel-kamelets

✅ VOTRE ENVIRONNEMENT EST PRÊT QUAND:

kubectl get pods -n camel-k montre 1/1 Running

kubectl get kamelets liste des Kamelets

kamel run --dev fonctionne sans erreur

🎉 BON DÉVELOPPEMENT !