CREATE TABLE IF NOT EXISTS payment_audit_log (
    id SERIAL PRIMARY KEY,
    transaction_id VARCHAR(64),
    step VARCHAR(50),
    status VARCHAR(20),
    details TEXT,
    trace_id VARCHAR(64),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS payment_dead_letter (
    id SERIAL PRIMARY KEY,
    transaction_id VARCHAR(64),
    payload TEXT, -- raw XML
    error_details TEXT,
    trace_id VARCHAR(64),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- Routing reference table for dynamic multi-Kamelet recipient list
CREATE TABLE IF NOT EXISTS payment_routing_rules (
    id SERIAL PRIMARY KEY,
    format VARCHAR(50),
    recipients TEXT,
    is_active BOOLEAN DEFAULT true
);

-- Seed sample rules
INSERT INTO payment_routing_rules (format, recipients, is_active) VALUES
('pacs008', 'kamelet:audit-to-db,kamelet:kafka-producer?topic=corebanking,kamelet:kafka-producer?topic=aml', true)
ON CONFLICT DO NOTHING;

INSERT INTO payment_routing_rules (format, recipients, is_active) VALUES
('pain001', 'kamelet:audit-to-db,kamelet:kafka-producer?topic=treasury', true)
ON CONFLICT DO NOTHING;

INSERT INTO payment_routing_rules (format, recipients, is_active) VALUES
('pain002', 'kamelet:audit-to-db,kamelet:kafka-producer?topic=reporting', true)
ON CONFLICT DO NOTHING;

INSERT INTO payment_routing_rules (format, recipients, is_active) VALUES
('pacs002', 'kamelet:audit-to-db,kamelet:kafka-producer?topic=settlement', true)
ON CONFLICT DO NOTHING;

INSERT INTO payment_routing_rules (format, recipients, is_active) VALUES
('mt103', 'kamelet:audit-to-db,kamelet:kafka-producer?topic=swift,kamelet:kafka-producer?topic=sanctions', true)
ON CONFLICT DO NOTHING;
